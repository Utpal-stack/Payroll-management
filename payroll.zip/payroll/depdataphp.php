<?php
       include('config.php');
       $sql="SELECT * FROM department;";
       $result=mysqli_query($con,$sql);     
?>